# WDIM393H - Group Project Repo

## Week 3 Homework - Markup

  * Nate
    * Added header and footer to April's about page
    * Created portfolio/index.html, added header and footer
    * Added horizontal rule to each page to divide content from header and footer
    * Discovered all the extra work April did that didn't merge into master
    * Integrated April's work into the current structure
    * Added a video to the front page
    * Added some of my own stuff
    * Pushed to gh-pages
